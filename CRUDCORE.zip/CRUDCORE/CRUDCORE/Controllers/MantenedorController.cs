﻿using Microsoft.AspNetCore.Mvc;
using CRUDCORE.Datos;
using CRUDCORE.Models;
namespace CRUDCORE.Controllers
{
    public class MantenedorController : Controller
    {
        ContactoDatos _ContactoDatos= new ContactoDatos();
        public IActionResult Listar()
        {
            //vista lista de los contactos
            var oLista = _ContactoDatos.Listar();   
            return View(oLista);
        }

        public IActionResult Guardar()
        {
            //vista sola
            return View();
        }

        [HttpPost]
        public IActionResult Guardar(ContactoModel oContacto)
        {
            //recibe el obj y lo guarda en db

            if (!ModelState.IsValid)
            {
                return View();
            }
            var resp = _ContactoDatos.Guardar(oContacto);
            if (resp)
                return RedirectToAction("Listar");
            else
                return View();
        }

        public IActionResult Editar(int IdContacto)
        {
            //vista sola
            var oContacto = _ContactoDatos.Obtener(IdContacto);
            return View(oContacto);
            
        }

        [HttpPost]
        public IActionResult Editar(ContactoModel oContacto)
        {
            if (!ModelState.IsValid)
            {
                return View();
            }
            var resp = _ContactoDatos.Editar(oContacto);
            if (resp)
                return RedirectToAction("Listar");
            else
                return View();
        }


        public IActionResult Eliminar(int IdContacto)
        {
            //vista sola
            var oContacto = _ContactoDatos.Obtener(IdContacto);
            return View(oContacto);

        }

        [HttpPost]
        public IActionResult Eliminar(ContactoModel oContacto)
        {
           
            var resp = _ContactoDatos.Eliminar(oContacto.IdContacto);
            if (resp)
                return RedirectToAction("Listar");
            else
                return View();
        }

    }
}
